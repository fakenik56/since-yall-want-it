let rendererWindowId = null;

const RENDERER_URL = chrome.runtime.getURL("renderer.html");
const EXTENSION_ROOT = chrome.runtime.getURL("");

function isTrustedExtensionSender(sender) {
  return (
    sender?.id === chrome.runtime.id &&
    typeof sender.url === "string" &&
    sender.url.startsWith(EXTENSION_ROOT)
  );
}

function isRendererSender(sender) {
  return isTrustedExtensionSender(sender) && sender.url === RENDERER_URL;
}

async function setTarget(tab) {
  if (!tab?.id) throw new Error("No active tab.");

  // executeScript defaults to Chrome's ISOLATED world. Do not change this to MAIN:
  // page JavaScript must never execute or inspect extension JavaScript state.
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["content.js"]
  });

  await chrome.storage.session.set({
    targetTabId: tab.id,
    targetTitle: tab.title || "Talkomatic"
  });

  try {
    const calibration = await chrome.tabs.sendMessage(tab.id, {
      type: "BRAILLE_GET_CALIBRATION"
    });
    if (calibration) {
      await chrome.storage.session.set({ calibration });
    }
  } catch (_) {
    // Calibration is optional.
  }
}

chrome.action.onClicked.addListener(async (tab) => {
  try {
    await setTarget(tab);

    if (rendererWindowId !== null) {
      try {
        await chrome.windows.update(rendererWindowId, { focused: true });
        return;
      } catch (_) {
        rendererWindowId = null;
      }
    }

    const win = await chrome.windows.create({
      url: RENDERER_URL,
      type: "popup",
      width: 410,
      height: 780
    });

    rendererWindowId = win.id ?? null;
  } catch (err) {
    console.error("Could not start renderer:", err);
  }
});

chrome.windows.onRemoved.addListener((id) => {
  if (id === rendererWindowId) rendererWindowId = null;
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return;

  // Only the extension-owned renderer page may command frames or stop output.
  if (msg.type === "BRAILLE_FRAME") {
    if (!isRendererSender(sender)) return;

    const text = String(msg.text ?? "").slice(0, 4000);
    chrome.storage.session.get("targetTabId").then(({ targetTabId }) => {
      if (targetTabId == null) return;
      chrome.tabs.sendMessage(targetTabId, {
        type: "BRAILLE_FRAME",
        text
      }).catch(() => {});
    });
    return;
  }

  if (msg.type === "BRAILLE_STOP") {
    if (!isRendererSender(sender)) return;

    chrome.storage.session.get("targetTabId").then(({ targetTabId }) => {
      if (targetTabId == null) return;
      chrome.tabs.sendMessage(targetTabId, {
        type: "BRAILLE_STOP",
        restore: msg.restore !== false
      }).catch(() => {});
    });
    return;
  }

  if (msg.type === "BRAILLE_RENDERER_INFO") {
    if (!isRendererSender(sender)) return;

    chrome.storage.session.get(
      ["targetTitle", "calibration"],
      (data) => sendResponse(data)
    );
    return true;
  }
});
