(() => {
  // This file is injected into Chrome's ISOLATED world. The page cannot read
  // this global or execute this script's functions. The only intentionally
  // shared surface is the chat-box DOM text that the extension updates.
  if (globalThis.__talkomaticBrailleVideoReceiverInstalled) return;
  globalThis.__talkomaticBrailleVideoReceiverInstalled = true;

  let originalText = null;
  let activeBox = null;

  const EXTENSION_ROOT = chrome.runtime.getURL("");

  function isTrustedExtensionSender(sender) {
    return (
      sender?.id === chrome.runtime.id &&
      typeof sender.url === "string" &&
      sender.url.startsWith(EXTENSION_ROOT) &&
      !sender.tab
    );
  }

  function findBox() {
    return (
      document.querySelector(
        '.chat-row.current-user[data-username="nik"] .chat-input[contenteditable="true"]'
      ) ||
      document.querySelector(
        '.chat-row.current-user .chat-input[contenteditable="true"]'
      )
    );
  }

  function updateChat(text) {
    const box = findBox();
    if (!box) return false;

    if (box !== activeBox) {
      activeBox = box;
      originalText = box.innerText;
    } else if (originalText === null) {
      originalText = box.innerText;
    }

    box.textContent = text;

    // Talkomatic must receive an input event for its own state to notice the
    // text change. The website can therefore observe the resulting text/event,
    // but it cannot inspect the extension's renderer, capture, or JS state.
    box.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        inputType: "insertText",
        data: null
      })
    );

    return true;
  }

  function restore() {
    if (!activeBox || originalText === null) return;

    activeBox.textContent = originalText;
    activeBox.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        inputType: "insertText",
        data: null
      })
    );

    originalText = null;
    activeBox = null;
  }

  function getCalibration() {
    const box = findBox();
    if (!box) return null;

    const style = getComputedStyle(box);
    const probe = document.createElement("span");
    probe.textContent = "⣿";

    Object.assign(probe.style, {
      position: "fixed",
      left: "-9999px",
      top: "-9999px",
      visibility: "hidden",
      pointerEvents: "none",
      whiteSpace: "pre",
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      fontWeight: style.fontWeight,
      fontStyle: style.fontStyle,
      lineHeight: style.lineHeight
    });

    document.body.appendChild(probe);
    const rect = probe.getBoundingClientRect();
    probe.remove();

    const cellWidth = rect.width || 8;
    const cellHeight = rect.height || 16;

    return {
      cellWidth,
      cellHeight,
      dotAspect: (cellWidth / 2) / (cellHeight / 4)
    };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!isTrustedExtensionSender(sender)) return;
    if (!msg || typeof msg !== "object") return;

    if (msg.type === "BRAILLE_FRAME") {
      sendResponse({ ok: updateChat(String(msg.text ?? "").slice(0, 4000)) });
      return;
    }

    if (msg.type === "BRAILLE_STOP") {
      if (msg.restore !== false) restore();
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === "BRAILLE_GET_CALIBRATION") {
      sendResponse(getCalibration());
    }
  });
})();
