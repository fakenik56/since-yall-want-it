Talkomatic Braille Video 1.1
============================

Chrome / Chromium / Edge (Manifest V3)

Install:
1. Unzip this folder.
2. Open chrome://extensions
3. Enable Developer mode.
4. Click "Load unpacked".
5. Select the unzipped folder.
6. Open your Talkomatic room.
7. Click the extension icon while that Talkomatic tab is active.
8. Choose a local video OR click "Share desktop" and select a screen/window.

Privacy / isolation:
- The renderer and desktop MediaStream live on the extension's own
  chrome-extension:// page, not inside Talkomatic.
- content.js is injected into Chrome's ISOLATED world, not the page's MAIN world.
  Do not change that behavior to MAIN.
- No extension files are declared web-accessible.
- The manifest uses a restrictive extension-page CSP with no network connections.
- Background/content message handlers validate that messages came from this
  extension before acting on them.
- The page receives only the generated Unicode Braille text through its own
  contenteditable chat box. It cannot directly read the chosen video, desktop
  MediaStream, renderer DOM, canvas pixels, or extension JavaScript state.
- Because the extension intentionally changes the page's chat box, Talkomatic's
  own JavaScript can observe that resulting text and its input event. That part
  cannot be hidden while still making Talkomatic send/render the text.

Desktop sharing:
- "Share desktop" uses Chrome's desktopCapture picker.
- Chrome shows the user a picker; capture starts only after the user chooses a
  screen/window.
- Capture stops when you press "Stop sharing", stop it from Chrome's sharing UI,
  or close the renderer window.
- Desktop pixels are converted to Braille locally. They are not uploaded by this
  extension.

Notes:
- Keep FPS modest (around 3-6) to avoid excessive live-typing updates.
- The extension does not upload selected video or desktop pixels anywhere.
- Different users' OS/font fallback can still render Unicode Braille with slightly
  different proportions. The extension calibrates against your current Talkomatic
  box but cannot control other users' fonts.
