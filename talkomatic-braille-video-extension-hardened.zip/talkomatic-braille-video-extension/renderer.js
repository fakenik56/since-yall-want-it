"use strict";

const $ = (id) => document.getElementById(id);

const video = $("video");
const fileInput = $("file");
const titleInput = $("title");
const fpsSlider = $("fps");
const fpsValue = $("fpsValue");
const thresholdSlider = $("threshold");
const thresholdValue = $("thresholdValue");
const invertCheck = $("invert");
const status = $("status");
const preview = $("preview");
const canvas = $("canvas");
const desktopButton = $("desktop");
const stopDesktopButton = $("stopDesktop");
const ctx = canvas.getContext("2d", { willReadFrequently: true });

const COLS = 20;
const SOURCE_W = COLS * 2;

let fps = 5;
let threshold = 120;
let invert = false;
let titleText = "";
let timer = null;
let objectURL = null;
let desktopStream = null;
let dotAspect = 1;
let sourceKind = "none";

const BRAILLE = [
  [0x01, 0x08],
  [0x02, 0x10],
  [0x04, 0x20],
  [0x40, 0x80]
];

chrome.runtime.sendMessage(
  { type: "BRAILLE_RENDERER_INFO" },
  (info) => {
    if (chrome.runtime.lastError) return;
    if (info?.targetTitle) {
      $("target").textContent = `Target: ${info.targetTitle}`;
    }
    if (info?.calibration?.dotAspect) {
      dotAspect = info.calibration.dotAspect;
    }
  }
);

function toBraille(binary, width, height) {
  const rows = Math.floor(height / 4);
  const cols = Math.floor(width / 2);
  let output = "";

  for (let cy = 0; cy < rows; cy++) {
    let line = "";

    for (let cx = 0; cx < cols; cx++) {
      let bits = 0;

      for (let dy = 0; dy < 4; dy++) {
        for (let dx = 0; dx < 2; dx++) {
          const x = cx * 2 + dx;
          const y = cy * 4 + dy;
          if (binary[y * width + x]) bits |= BRAILLE[dy][dx];
        }
      }

      line += String.fromCodePoint(0x2800 + bits);
    }

    output += line;
    if (cy < rows - 1) output += "\n";
  }

  return output;
}

function getRenderSize() {
  if (!video.videoWidth || !video.videoHeight) return null;

  const sourceAspect = video.videoWidth / video.videoHeight;
  let height = (SOURCE_W / sourceAspect) * dotAspect;
  height = Math.round(height / 4) * 4;
  height = Math.max(4, Math.min(32, height));

  return { width: SOURCE_W, height };
}

function renderFrame() {
  if (video.readyState < 2 || video.paused || video.ended) return;

  const size = getRenderSize();
  if (!size) return;

  const { width, height } = size;
  canvas.width = width;
  canvas.height = height;

  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, width, height);

  const srcAspect = video.videoWidth / video.videoHeight;
  const dstAspect = width / height;

  let dw, dh, dx, dy;

  if (srcAspect > dstAspect) {
    dw = width;
    dh = width / srcAspect;
    dx = 0;
    dy = (height - dh) / 2;
  } else {
    dh = height;
    dw = height * srcAspect;
    dy = 0;
    dx = (width - dw) / 2;
  }

  ctx.drawImage(video, dx, dy, dw, dh);

  const rgba = ctx.getImageData(0, 0, width, height).data;
  const binary = new Uint8Array(width * height);

  for (let i = 0, p = 0; i < rgba.length; i += 4, p++) {
    const lum =
      rgba[i] * 0.2126 +
      rgba[i + 1] * 0.7152 +
      rgba[i + 2] * 0.0722;

    let on = lum >= threshold;
    if (invert) on = !on;
    binary[p] = on ? 1 : 0;
  }

  let text = toBraille(binary, width, height);
  const title = titleText.replace(/[\r\n]/g, " ").slice(0, COLS);

  if (title) {
    const len = Array.from(title).length;
    const pad = Math.max(0, Math.floor((COLS - len) / 2));
    text = " ".repeat(pad) + title + "\n" + text;
  }

  preview.textContent = text;
  chrome.runtime.sendMessage({ type: "BRAILLE_FRAME", text });
}

function restartTimer() {
  if (timer !== null) clearInterval(timer);
  timer = setInterval(renderFrame, 1000 / fps);
}

function releaseObjectURL() {
  if (!objectURL) return;
  URL.revokeObjectURL(objectURL);
  objectURL = null;
}

function stopDesktopCapture({ clearVideo = true } = {}) {
  if (desktopStream) {
    for (const track of desktopStream.getTracks()) track.stop();
    desktopStream = null;
  }

  stopDesktopButton.disabled = true;

  if (sourceKind === "desktop") {
    sourceKind = "none";
    if (clearVideo) {
      video.pause();
      video.srcObject = null;
      video.removeAttribute("src");
      video.load();
    }
  }
}

function prepareForNewSource() {
  video.pause();
  stopDesktopCapture({ clearVideo: false });
  video.srcObject = null;
  releaseObjectURL();
  sourceKind = "none";
}

function requestDesktopStream() {
  return new Promise((resolve, reject) => {
    chrome.desktopCapture.chooseDesktopMedia(
      ["screen", "window"],
      (streamId) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!streamId) {
          reject(new DOMException("Desktop sharing was cancelled.", "AbortError"));
          return;
        }

        navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            mandatory: {
              chromeMediaSource: "desktop",
              chromeMediaSourceId: streamId,
              maxFrameRate: 30
            }
          }
        }).then(resolve, reject);
      }
    );
  });
}

fileInput.addEventListener("change", async () => {
  const file = fileInput.files?.[0];
  if (!file) return;

  prepareForNewSource();

  objectURL = URL.createObjectURL(file);
  sourceKind = "file";
  video.loop = true;
  video.src = objectURL;
  video.load();
  status.textContent = `Loading ${file.name}...`;

  try {
    await video.play();
    status.textContent =
      `${video.videoWidth || "?"}×${video.videoHeight || "?"} • rendering file`;
  } catch (err) {
    console.error(err);
    status.textContent = `Could not play: ${err.name}: ${err.message}`;
  }
});

desktopButton.addEventListener("click", async () => {
  desktopButton.disabled = true;
  status.textContent = "Choose a screen or window to share...";

  try {
    prepareForNewSource();
    const stream = await requestDesktopStream();
    desktopStream = stream;
    sourceKind = "desktop";
    video.loop = false;
    video.removeAttribute("src");
    video.srcObject = stream;

    const [track] = stream.getVideoTracks();
    if (track) {
      track.addEventListener("ended", () => {
        if (sourceKind !== "desktop") return;
        stopDesktopCapture();
        status.textContent = "Desktop sharing ended.";
      }, { once: true });
    }

    await video.play();
    stopDesktopButton.disabled = false;
    status.textContent = "Desktop sharing • rendering locally";
  } catch (err) {
    if (err?.name === "AbortError") {
      status.textContent = "Desktop sharing cancelled.";
    } else {
      console.error(err);
      status.textContent = `Desktop sharing failed: ${err?.message || String(err)}`;
    }
    stopDesktopCapture();
  } finally {
    desktopButton.disabled = false;
  }
});

stopDesktopButton.addEventListener("click", () => {
  stopDesktopCapture();
  status.textContent = "Desktop sharing stopped.";
});

video.addEventListener("loadedmetadata", () => {
  if (sourceKind === "desktop") {
    status.textContent = `${video.videoWidth}×${video.videoHeight} • desktop sharing`;
    return;
  }

  const duration = Number.isFinite(video.duration)
    ? `${video.duration.toFixed(1)}s`
    : "live";
  status.textContent = `${video.videoWidth}×${video.videoHeight} • ${duration}`;
});

video.addEventListener("error", () => {
  const err = video.error;
  status.textContent =
    `Video error ${err?.code ?? "?"}: ${err?.message || "unknown error"}`;
});

titleInput.addEventListener("input", () => {
  titleText = titleInput.value;
});

fpsSlider.addEventListener("input", () => {
  fps = Number(fpsSlider.value);
  fpsValue.textContent = String(fps);
  restartTimer();
});

thresholdSlider.addEventListener("input", () => {
  threshold = Number(thresholdSlider.value);
  thresholdValue.textContent = String(threshold);
});

invertCheck.addEventListener("change", () => {
  invert = invertCheck.checked;
});

$("play").addEventListener("click", async () => {
  try {
    await video.play();
    status.textContent = sourceKind === "desktop" ? "Desktop sharing • rendering locally" : "Rendering...";
  } catch (err) {
    status.textContent = `Play failed: ${err.message}`;
  }
});

$("pause").addEventListener("click", () => {
  video.pause();
  status.textContent = "Preview/rendering paused. Desktop capture remains local.";
});

$("stop").addEventListener("click", () => {
  video.pause();
  chrome.runtime.sendMessage({
    type: "BRAILLE_STOP",
    restore: true
  });
  status.textContent = "Output stopped and original text restored.";
});

window.addEventListener("beforeunload", () => {
  if (timer !== null) clearInterval(timer);
  stopDesktopCapture();
  releaseObjectURL();
});

restartTimer();
